/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   check_buff.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tpacaly <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/04/03 10:14:36 by tpacaly           #+#    #+#             */
/*   Updated: 2018/04/03 10:14:37 by tpacaly          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../include/lemin.h"

static void	ft_check_first_line(void)
{
	int nbr;

	((nbr = ft_strlen(s()->buff)) == 0) ? ft_error("[ants] Empty line.") : 0;
	(s()->buff[0] == 48) ? ft_error("0 ants.") : 0;
	(ft_strlen(s()->buff) > 10) ? ft_error("[ants] overflow.") : 0;
	(ft_strlen(s()->buff) == 10 && s()->buff[0] > '2') ?
	ft_error("[ants] Wrong data.") : 0;
	nbr = 0;
	while (s()->buff[nbr])
	{
		if (s()->buff[nbr] < '0' || s()->buff[nbr] > '9')
			ft_error("[ants] Wrong data.");
		nbr++;
	}
	s()->ants = ft_atoi(s()->buff);
	if (s()->ants > 2147483647)
		ft_error("[ants] Overflow");
	nbr = 0;
	while (s()->buff[nbr] >= '0' && s()->buff[nbr] <= '9')
		nbr++;
	(s()->buff[nbr] != 0) ? ft_error("[ants] Wrong data.") : 0;
	s()->bool_ants = 1;
}

void		ft_rooms_bis(int nbr)
{
	(s()->buff[++nbr] < '0' || s()->buff[nbr] > '9') ?
	ft_error("[room] Wrong y") : 0;
	while (s()->buff[nbr] >= '0' && s()->buff[nbr] <= '9')
		nbr++;
	(s()->buff[nbr] != 32) ? ft_error("[room] missing space.") : 0;
	(s()->buff[++nbr] < '0' || s()->buff[nbr] > '9') ?
	ft_error("[room] Wrong x") : 0;
	while (s()->buff[nbr] >= '0' && s()->buff[nbr] <= '9')
		nbr++;
	(s()->buff[nbr] != 0) ? ft_error("[room] must end by \\0") : 0;
	if (s()->room_for_start != 0)
		s()->start_room = ft_strdup(s()->buff);
	if (s()->room_for_end != 0)
		s()->end_room = ft_strdup(s()->buff);
	s()->room_for_start = 0;
	s()->room_for_end = 0;
}

static void	ft_check_rooms(void)
{
	int nbr;

	((nbr = ft_strlen(s()->buff)) == 0) ?
	ft_error("[room] Empty line.") : 0;
	(s()->buff[0] == 'L' || s()->buff[0] < 33 || s()->buff[0] > 126) ?
	ft_error("[room] Start with 'L'.") : 0;
	nbr = 0;
	while (s()->buff[nbr] > 32 && s()->buff[nbr] < 127)
		nbr++;
	if (s()->buff[nbr] != 32)
	{
		s()->bool_rooms = 1;
		return ;
	}
	nbr = 0;
	while (s()->buff[nbr] > 32 && s()->buff[nbr] < 127)
	{
		if (s()->buff[nbr] == '-')
			ft_error("[room] '-' found in a name.");
		nbr++;
	}
	ft_rooms_bis(nbr);
}

void		ft_buff_bis(void)
{
	if (ft_strcmp(s()->buff, "##end") == 0)
	{
		s()->room_for_end = 1;
		(s()->room_for_end == 1 && s()->room_for_start == 1) ?
		ft_error("[instruction] end + start.") : 0;
		s()->bool_end += 1;
		(s()->bool_end > 1) ? ft_error("[instruction] 1 end allowed.") : 0;
		return ;
	}
	else if (s()->bool_rooms == 0 && ft_strncmp(s()->buff, "##", 2) != 0
		&& ft_strncmp(s()->buff, "#", 1) != 0)
		ft_check_rooms();
	if (s()->bool_rooms != 0 && ft_strncmp(s()->buff, "##", 2) != 0
		&& ft_strncmp(s()->buff, "#", 1) != 0)
	{
		(s()->room_for_end == 1 || s()->room_for_start == 1) ?
		ft_error("No end, no start allowed before pipes.") : 0;
		(s()->bool_start == 0 || s()->bool_end == 0) ?
		ft_error("No start &&/|| no end.") : 0;
		ft_check_pipes();
	}
}

void		ft_check_buff(int counter)
{
	(void)counter;
	if (s()->bool_ants == 0)
	{
		if (ft_strncmp(s()->buff, "##", 2) == 0)
		{
			if (ft_strcmp(s()->buff, "##start") == 0)
				ft_error("[ants] Wrong start.");
			(ft_strcmp(s()->buff, "##end") == 0) ? ft_error("Wrong end") : 0;
			return ;
		}
		else if (ft_strncmp(s()->buff, "#", 1) != 0)
			ft_check_first_line();
		return ;
	}
	else if (ft_strcmp(s()->buff, "##start") == 0)
	{
		s()->room_for_start = 1;
		(s()->room_for_end == 1 && s()->room_for_start == 1) ?
		ft_error("[instruction] end + start.") : 0;
		s()->bool_start += 1;
		(s()->bool_start > 1) ? ft_error("[instruction] 1 start allowed.") : 0;
		return ;
	}
	else
		ft_buff_bis();
}
