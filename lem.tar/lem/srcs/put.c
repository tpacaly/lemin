/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   put.c                                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tpacaly <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/04/03 10:17:25 by tpacaly           #+#    #+#             */
/*   Updated: 2018/04/03 10:17:26 by tpacaly          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../include/lemin.h"

char	*ft_strncpy(char *dst, char *src, int n)
{
	int i;

	i = 0;
	while (src[i] && n > 0)
	{
		dst[i] = src[i];
		i++;
		n--;
	}
	dst[i] = 0;
	return (dst);
}

void	ft_putstr_fd_free(char *str, int fd, char c, char dom)
{
	write(fd, str, ft_strlen(str));
	(dom == 1) ? free(str) : 0;
	(c == 0) ? 0 : write(fd, &c, 1);
}
