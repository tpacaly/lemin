/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   utils3.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tpacaly <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/04/03 10:56:13 by tpacaly           #+#    #+#             */
/*   Updated: 2018/04/03 10:56:13 by tpacaly          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../include/lemin.h"

void	ft_color(char color, char *str)
{
	if (color == 1)
		write(1, BLU, ft_strlen(BLU));
	else if (color == 2)
		write(1, YEL, ft_strlen(YEL));
	else if (color == 3)
		write(1, BLU, ft_strlen(BLU));
	else if (color == 4)
		write(1, CYA, ft_strlen(CYA));
	else if (color == 5)
		write(1, GRE, ft_strlen(GRE));
	else if (color == 6)
		write(1, RED, ft_strlen(RED));
	else if (color == 7)
		write(1, WHI, ft_strlen(WHI));
	ft_putstr_fd_free(str, 1, 10, 0);
	if (color != 0)
		write(1, RES, ft_strlen(RES));
}

void	ft_print_color(void)
{
	int index;

	index = -1;
	while (s()->tab[++index])
	{
		if (ft_strncmp(s()->tab[index], "##start", 8) == 0)
			ft_color(5, s()->tab[index]);
		else if (ft_strncmp(s()->tab[index], "##end", 8) == 0)
			ft_color(6, s()->tab[index]);
		else if (ft_strncmp(s()->tab[index], "##", 2) == 0)
			ft_color(7, s()->tab[index]);
		else if (ft_strncmp(s()->tab[index], "#", 1) == 0 &&
			ft_strncmp(s()->tab[index], "#", 2) != 0)
			ft_color(2, s()->tab[index]);
		else if (ft_count(s()->tab[index]) == 2)
			ft_color(3, s()->tab[index]);
		else
			ft_color(4, s()->tab[index]);
	}
	write(1, "\n", 1);
}

void	ft_usage(void)
{
	ft_putstr_fd_free(CYA"usage: ./lem-in [-quiet "RES, 1, 0, 0);
	ft_putstr_fd_free(CYA"| -color | -usage] < [map]"RES, 1, 10, 0);
	ft_putstr_fd_free(CYA"       ./lem-in [-quiet "RES, 1, 0, 0);
	ft_putstr_fd_free(CYA"| -color | -usage]"RES, 1, 10, 0);
	exit(1);
}

t_list	*ft_setroom(t_list *dst, char *data, int i)
{
	dst->x = ft_atoi(data + i);
	while (data[++i] != ' ')
		;
	dst->y = ft_atoi(data + i);
	return (dst);
}

t_list	*ft_newroom(char *data, char start, int xy)
{
	t_list	*ret;
	int		i;

	i = 0;
	if (!(ret = (t_list*)malloc(sizeof(t_list))))
		return (NULL);
	while (data[i] != ' ' && data[i] != 0)
		i++;
	if (!(ret->room = (char*)malloc(sizeof(char) * i + 1)))
		return (NULL);
	ret->room = ft_strncpy(ret->room, data, i);
	if (xy == 1)
		ret = ft_setroom(ret, data, i);
	ret->start = start;
	ret->marker = 0;
	ret->ants = start == 1 ? s()->ants : 0;
	ret->next = NULL;
	ret->link = NULL;
	return (ret);
}
