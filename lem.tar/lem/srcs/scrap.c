/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   scrap.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tpacaly <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/04/03 10:17:31 by tpacaly           #+#    #+#             */
/*   Updated: 2018/04/03 10:17:32 by tpacaly          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../include/lemin.h"

int		ft_replica(char **tab, char *name)
{
	int i;

	i = 0;
	while (tab[i])
	{
		if (!(ft_strcmp(tab[i], name)))
			return (1);
		i++;
	}
	return (0);
}

t_list	*ft_scroll(t_list *lst, char *name)
{
	while (lst != NULL)
	{
		if (!(ft_strcmp(lst->room, name)))
			return (lst);
		lst = lst->next;
	}
	return (NULL);
}

int		ft_check_end(t_list *lst, char **tab)
{
	int i;

	i = 0;
	while (tab[i])
	{
		lst = ft_scroll(s()->begin, tab[i]);
		if (lst->start == 2)
			return (0);
		i++;
	}
	return (1);
}

char	*ft_find_start_end(t_list *lst, int n)
{
	while (lst != NULL)
	{
		if (lst->start == n)
		{
			return (lst->room);
		}
		lst = lst->next;
	}
	return (NULL);
}

int		ft_check_graph(t_list *lst)
{
	while (lst != NULL)
	{
		if (lst->marker == 0)
			return (0);
		lst = lst->next;
	}
	lst = s()->begin;
	return (1);
}
