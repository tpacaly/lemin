/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   tools.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tpacaly <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/04/03 10:18:00 by tpacaly           #+#    #+#             */
/*   Updated: 2018/04/03 10:18:01 by tpacaly          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../include/lemin.h"

int		ft_dash(char *str)
{
	int i;

	i = -1;
	while (str[++i])
	{
		if (str[i] == '-')
			return (1);
	}
	return (0);
}

int		ft_atoi(const char *str)
{
	int nbr;
	int vle;

	nbr = 0000;
	while ((*str >= 0011 && *str <= 0015) || *str == 0040)
		str++;
	vle = (*str == 0055) ? -0001 : 0001;
	(*str == 0053 || *str == 0055) ? str++ : 0000;
	while (*str >= 0060 && *str <= 0071)
		nbr = (nbr * 0012) + ((int)*str++ - 0060);
	return (nbr * vle);
}

size_t	ft_strlen(const char *s)
{
	int i;

	i = 0;
	while (s[i])
	{
		i++;
	}
	return (i);
}

char	*ft_strsub(char const *s, unsigned int start, size_t len)
{
	char			*str;
	char			*s_2;
	unsigned int	u_i;

	if (s == NULL)
		return (NULL);
	u_i = 0;
	s_2 = (char *)s;
	str = (char *)malloc(sizeof(*str) * len + 1);
	if (str == NULL)
		return (NULL);
	while (s_2[start] && len > 0)
	{
		str[u_i] = s_2[start];
		u_i++;
		start++;
		len--;
	}
	str[u_i] = '\0';
	return (str);
}

int		ft_ispipe(char *pipe, char *name)
{
	int i;
	int j;

	i = 0;
	j = 0;
	if (pipe[i] != name[j])
		while (pipe[i] != '-')
			i++;
	while (pipe[i] == name[j])
	{
		i++;
		j++;
	}
	if (pipe[i] == '-' && name[j] == 0)
		return (0);
	while (pipe[i] != '-')
		i++;
	i++;
	j = 0;
	while (pipe[i + j] && name[j] == pipe[i + j])
		j++;
	if (pipe[i + j] == 0 && name[j] == 0)
		return (i);
	return (-1);
}
