/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tpacaly <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/04/03 10:15:43 by tpacaly           #+#    #+#             */
/*   Updated: 2018/04/03 10:15:43 by tpacaly          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../include/lemin.h"

int		ft_find_links(void)
{
	int i;

	i = 0;
	while (s()->tab[i][0] != '#' && ft_dash(s()->tab[i]) == 0)
		i++;
	return (i);
}

t_list	*ft_list(void)
{
	t_list	*lst;
	int		i;

	i = 1;
	lst = ft_init_lst();
	s()->begin = lst;
	while (s()->room[i])
	{
		if (ft_strcmp(s()->room[i], s()->start_room) == 0)
			lst->next = ft_newroom(s()->room[i], 1, 1);
		else if (ft_strcmp(s()->room[i], s()->end_room) == 0)
			lst->next = ft_newroom(s()->room[i], 2, 1);
		else
			lst->next = ft_newroom(s()->room[i], 0, 1);
		i++;
		lst = lst->next;
	}
	lst = s()->begin;
	return (lst);
}

int		ft_check_errors(void)
{
	int counter;

	counter = 1;
	(s()->ac > 2) ? ft_error("Wrong number of arguments.") : 0;
	while (get_next_line(0, &s()->buff) == 1)
	{
		if (s()->buff[0] == '\n' || s()->buff[0] == 0)
			break ;
		ft_check_buff(counter);
		if (s()->bool_stop == 1)
			break ;
		s()->tab = ft_malloc_tabtab(s()->tab, s()->buff);
		counter++;
		ft_strdel(&s()->buff);
	}
	if (s()->bool_start == 0 || s()->bool_end == 0 ||
		s()->ants == 0 || s()->nbr_pipes == 0)
		ft_error("Wrong data.");
	ft_get_tab();
	ft_get_tab();
	ft_matrice();
	return (0);
}

t_var	*s(void)
{
	static t_var	*v;

	if (!v)
		if (!(v = (t_var *)malloc(sizeof(t_var))))
			ft_error("malloc failure.");
	return (v);
}

int		main(int argc, char **argv)
{
	t_list *lst;

	s();
	ft_init(argc, argv);
	if (ft_check_errors() == 1)
		ft_error(NULL);
	lst = ft_list();
	ft_set_link(lst, s()->pipes);
	ft_algo(lst);
	return (0);
}
