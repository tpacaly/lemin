/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tpacaly <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/04/03 10:15:43 by tpacaly           #+#    #+#             */
/*   Updated: 2018/04/03 10:15:43 by tpacaly          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../include/lemin.h"

int		ft_find_links(void)
{
	int i;

	i = 0;
	while (s()->tab[i][0] != '#' && ft_dash(s()->tab[i]) == 0)
		i++;
	return (i);
}

t_list	*ft_list(void)
{
	t_list	*lst;
	int		i;

	i = 1;
	lst = ft_init_lst();
	s()->begin = lst;
	while (s()->room[i])
	{
		if (ft_strcmp(s()->room[i], s()->start_room) == 0)
			lst->next = ft_newroom(s()->room[i], 1, 1);
		else if (ft_strcmp(s()->room[i], s()->end_room) == 0)
			lst->next = ft_newroom(s()->room[i], 2, 1);
		else
			lst->next = ft_newroom(s()->room[i], 0, 1);
		i++;
		lst = lst->next;
	}
	lst = s()->begin;
	return (lst);
}

void	ft_init(int argc, char **argv)
{
	s()->av = argv;
	s()->ac = argc;
	s()->buff = NULL;
	s()->bool_start = 0;
	s()->bool_end = 0;
	s()->bool_rooms = 0;
	s()->start_room = NULL;
	s()->end_room = NULL;
	s()->ants = 0;
	s()->bool_ants = 0;
	s()->bool_stop = 0;
	s()->tab = NULL;
	s()->room_for_start = 0;
	s()->room_for_end = 0;
	s()->nbr_pipes = 0;
	s()->room = NULL;
	s()->pipes = NULL;
	s()->matrice = NULL;
	s()->path = NULL;
	s()->dist = 1;
	s()->bool_etun = 0;
	s()->result = NULL;
	s()->bonus = NULL;
}

t_var	*s(void)
{
	static t_var	*v;

	if (!v)
		if (!(v = (t_var *)malloc(sizeof(t_var))))
			ft_error("malloc failure.");
	return (v);
}

int		main(int argc, char **argv)
{
	t_list *lst;

	s();
	ft_init(argc, argv);
	if (ft_check_errors() == 1)
		ft_error(NULL);
	lst = ft_list();
	ft_set_link(lst, s()->pipes);
	ft_algo(lst);
	return (0);
}
