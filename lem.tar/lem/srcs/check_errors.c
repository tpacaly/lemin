/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   check_errors.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tpacaly <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/04/03 10:14:41 by tpacaly           #+#    #+#             */
/*   Updated: 2018/04/03 10:14:42 by tpacaly          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../include/lemin.h"

void		ft_error(char *str)
{
	ft_putstr_fd_free(RED"ERROR"RES, 1, 0, 0);
	if (str == NULL)
	{
		write(2, "\n", 1);
		return ;
	}
	ft_putstr_fd_free(RED" : "RES, 1, 0, 0);
	ft_putstr_fd_free(str, 1, 10, 0);
	exit(1);
}

int			ft_check_errors(void)
{
	int counter;

	counter = 1;
	(s()->ac > 2) ? ft_error("Wrong number of arguments.") : 0;
	while (get_next_line(0, &s()->buff) == 1)
	{
		if (s()->buff[0] == '\n' || s()->buff[0] == 0)
			break ;
		ft_check_buff(counter);
		if (s()->bool_stop == 1)
			break ;
		s()->tab = ft_malloc_tabtab(s()->tab, s()->buff);
		counter++;
		ft_strdel(&s()->buff);
	}
	if (s()->bool_start == 0 || s()->bool_end == 0 ||
		s()->ants == 0 || s()->nbr_pipes == 0)
		ft_error("Wrong data.");
	ft_get_tab();
	ft_get_tab();
	ft_matrice();
	return (0);
}
