/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   malloc_tab.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tpacaly <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/04/03 10:15:49 by tpacaly           #+#    #+#             */
/*   Updated: 2018/04/03 10:15:51 by tpacaly          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../include/lemin.h"

void	ft_free_tab(char **tab)
{
	int i;

	i = -1;
	while (tab[++i])
		ft_strdel(&tab[i]);
	ft_strdel(&tab[i]);
	free(tab);
	tab = NULL;
}

void	ft_create(int counter)
{
	if (!(s()->tab = (char **)malloc(sizeof(char *) * counter + 1)))
		ft_error("malloc failure.");
	s()->tab[0] = ft_strdup(s()->buff);
	s()->tab[1] = 0;
}

void	ft_new(int counter)
{
	char	**t;
	int		i;

	i = -1;
	if (!(t = (char **)malloc(sizeof(char *) * counter + 1)))
		ft_error("malloc failure.");
	t[counter] = 0;
	while (s()->tab[++i])
		t[i] = ft_strdup(s()->tab[i]);
	t[i] = ft_strdup(s()->buff);
	ft_free_tab(s()->tab);
	if (!(s()->tab = (char **)malloc(sizeof(char *) * counter + 1)))
		ft_error("malloc failure.");
	s()->tab[counter] = 0;
	i = -1;
	while (t[++i])
		s()->tab[i] = ft_strdup(t[i]);
	ft_free_tab(t);
	t = NULL;
}

void	ft_malloc_tab(int counter)
{
	if (!s()->tab)
		ft_create(counter);
	else
		ft_new(counter);
}
