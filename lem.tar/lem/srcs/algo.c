/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   algo.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tpacaly <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/04/03 10:13:57 by tpacaly           #+#    #+#             */
/*   Updated: 2018/04/03 10:13:58 by tpacaly          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../include/lemin.h"
#include <string.h>
#include <limits.h>

t_list	*ft_best_return(t_list *lst)
{
	int		i;
	int		best;
	t_list	*tmp;

	i = 0;
	best = INT_MAX;
	while (lst->link[i])
	{
		if (ft_scroll(s()->begin, lst->link[i])->marker < best &&
				ft_scroll(s()->begin, lst->link[i])->marker != 0)
		{
			best = ft_scroll(s()->begin, lst->link[i])->marker;
			tmp = ft_scroll(s()->begin, lst->link[i]);
		}
		i++;
	}
	return (tmp);
}

void	ft_algo_bis(int *j, t_list *lst, int *flag, int *i)
{
	lst = ft_scroll(s()->begin, s()->dtab[*i]);
	while (lst->link[*j])
	{
		if (ft_replica(s()->dtab, lst->link[*j]) == 0)
		{
			lst->marker = (lst->marker == 0) ? s()->dist : lst->marker;
			if (lst->link[*j])
				s()->dtab = ft_malloc_tabtab(s()->dtab, lst->link[*j]);
			if (ft_scroll(s()->begin, lst->link[*j])->marker == 0)
			{
				*flag += 1;
				ft_scroll(s()->begin, lst->link[*j])->marker =
					lst->marker + 1;
			}
		}
		*j += 1;
	}
	if (ft_check_end(s()->begin, s()->dtab) == 0)
		s()->bool_etun = 1;
	*i += 1;
	if (*flag != 0)
	{
		s()->dist++;
		*flag = 0;
	}
}

void	ft_algo(t_list *lst)
{
	int		i;
	int		j;
	int		flag;
	t_list	*walk;

	walk = NULL;
	s()->dtab = ft_malloc_tabtab(NULL, ft_find_start_end(lst, 1));
	i = 0;
	flag = 0;
	while (ft_check_graph(s()->begin) == 0 &&
			s()->bool_etun == 0 && s()->dtab[i])
	{
		j = 0;
		ft_algo_bis(&j, lst, &flag, &i);
	}
	ft_find_path(walk, lst);
	ft_move(walk);
	exit(1);
}
