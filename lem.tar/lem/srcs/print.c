/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   print.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tpacaly <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/04/03 10:17:13 by tpacaly           #+#    #+#             */
/*   Updated: 2018/04/03 10:17:14 by tpacaly          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../include/lemin.h"

static char	*ft_strrjoin(char *s1, char *s2, char n)
{
	unsigned int	u_i;
	unsigned int	u_j;
	char			*dest;

	u_i = 0;
	u_j = 0;
	if (!(dest = (char *)malloc(sizeof(char) *
		(ft_strlen(s1) + ft_strlen(s2) + 1))))
		ft_error("Malloc failure");
	dest[ft_strlen(s1) + ft_strlen(s2)] = 0;
	while (s1[u_i])
	{
		dest[u_i] = s1[u_i];
		u_i++;
	}
	while (s2[u_j])
	{
		dest[u_i + u_j] = s2[u_j];
		u_j++;
	}
	(n == 1) ? ft_strdel(&s1) : 0;
	(n == 2) ? ft_strdel(&s2) : 0;
	(n == 3) ? ft_strdel(&s1) : 0;
	(n == 3) ? ft_strdel(&s2) : 0;
	return (dest);
}

void		ft_print(int name, char *room)
{
	char *tmp;

	tmp = NULL;
	if (!s()->path)
	{
		tmp = ft_strrjoin("L", ft_itoa(name), 2);
		tmp = ft_strrjoin(tmp, "-", 1);
		s()->path = ft_strrjoin(tmp, room, 1);
	}
	else
	{
		tmp = ft_strrjoin("L", ft_itoa(name), 2);
		tmp = ft_strrjoin(tmp, "-", 1);
		tmp = ft_strrjoin(tmp, room, 1);
		tmp = ft_strrjoin(tmp, " ", 1);
		s()->path = ft_strrjoin(tmp, s()->path, 3);
	}
}

void		ft_print_map(void)
{
	if (s()->ac == 1)
	{
		ft_puttab(s()->tab);
		return ;
	}
	if (ft_strcmp(s()->av[1], "-color") == 0)
	{
		s()->bonus = ft_strdup("-color");
		ft_print_color();
	}
	else if (ft_strcmp(s()->av[1], "-quiet") == 0 ||
		ft_strcmp(s()->av[1], "-cquiet") == 0)
	{
		s()->bonus = (ft_strcmp(s()->av[1], "-cquiet") == 0)
		? ft_strdup("-color") : NULL;
		return ;
	}
	else if (ft_strcmp(s()->av[1], "-usage") == 0)
		ft_usage();
	else if (ft_strcmp(s()->av[1], "-matrice") == 0)
		ft_puttab(s()->matrice);
	else
		ft_error("Wrong arguments.");
}

void		ft_puttab(char **tab)
{
	int y;
	int x;

	y = 0;
	while (tab[y])
	{
		x = 0;
		while (tab[y][x])
		{
			write(1, &tab[y][x], 1);
			x++;
		}
		write(1, "\n", 1);
		y++;
	}
}

int			ft_ytab(char **tab)
{
	int y;

	y = -1;
	while (tab[++y])
		;
	return (y);
}
