/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   check_pipes.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tpacaly <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/04/03 10:14:47 by tpacaly           #+#    #+#             */
/*   Updated: 2018/04/03 10:14:48 by tpacaly          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../include/lemin.h"

int			ft_count(char *s)
{
	int index;
	int space;

	index = 0;
	space = 0;
	while (s[index])
	{
		if (s[0] == '#')
			return (1);
		if (s[index] == 32 || s[index] == '\t')
			space++;
		if (space > 2)
			return (1);
		index++;
	}
	return (space);
}

t_comp		ft_init_c(void)
{
	t_comp c;

	c.occurence = 0;
	c.index = 0;
	c.limit = 0;
	c.i = 0;
	c.j = 0;
	return (c);
}

void		ft_compare_last_name(int n)
{
	t_comp c;

	c = ft_init_c();
	while (s()->tab[c.index])
	{
		c.i = 0;
		c.j = 0;
		if (s()->tab[c.index][0] == '#')
		{
			while (s()->tab[c.index] && s()->tab[c.index][0] == '#')
				c.index++;
			if (c.limit++ == 0)
				c.index++;
		}
		if (c.limit++ == 0)
			c.index++;
		while (s()->tab[c.index] && ft_count(s()->tab[c.index]) != 2)
			c.index++;
		if (!s()->tab[c.index])
			break ;
		ft_last_bis(&c, n);
	}
	if (c.occurence != 1)
		s()->bool_stop = 1;
}

void		ft_compare_first_name(int n)
{
	t_comp c;

	c = ft_init_c();
	(void)n;
	while (s()->tab[c.index])
	{
		c.i = 0;
		if (s()->tab[c.index][0] == '#')
		{
			while (s()->tab[c.index] && s()->tab[c.index][0] == '#')
				c.index++;
			if (c.limit++ == 0)
				c.index++;
		}
		if (c.limit++ == 0)
			c.index++;
		while (s()->tab[c.index] && ft_count(s()->tab[c.index]) != 2)
			c.index++;
		if (!s()->tab[c.index])
			break ;
		ft_first_bis(&c);
	}
	if (c.occurence != 1)
		s()->bool_stop = 1;
}

void		ft_check_pipes(void)
{
	int hyphen;
	int index;

	index = -1;
	hyphen = 0;
	while (s()->buff[++index] > 32 && s()->buff[index] < 127)
	{
		if ((hyphen = (s()->buff[index] == '-') ? hyphen + 1 : hyphen) > 1)
			break ;
	}
	if (hyphen != 1 || s()->buff[index] != 0)
	{
		s()->bool_stop = 1;
		return ;
	}
	index = 0;
	while (s()->buff[index] && s()->buff[index] != '-')
		index++;
	ft_compare_first_name(index);
	if (s()->bool_stop > 0)
		return ;
	ft_compare_last_name(index + 1);
	if (s()->bool_stop > 0)
		return ;
	s()->nbr_pipes++;
}
