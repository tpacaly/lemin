/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   tempo.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tpacaly <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/04/03 10:17:52 by tpacaly           #+#    #+#             */
/*   Updated: 2018/04/03 10:17:54 by tpacaly          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../include/lemin.h"

int	ft_strcmp(const char *s1, const char *s2)
{
	unsigned int	u_i;
	unsigned char	*s_1;
	unsigned char	*s_2;

	s_1 = (unsigned char *)s1;
	s_2 = (unsigned char *)s2;
	u_i = 0;
	while (s_1[u_i] && (s_1[u_i] == s_2[u_i]))
	{
		u_i++;
	}
	return ((unsigned char)s_1[u_i] - (unsigned char)s_2[u_i]);
}
