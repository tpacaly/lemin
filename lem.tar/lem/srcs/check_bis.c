/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   check_bis.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tpacaly <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/04/03 10:14:29 by tpacaly           #+#    #+#             */
/*   Updated: 2018/04/03 10:14:30 by tpacaly          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../include/lemin.h"

void		ft_first_bis(t_comp *c)
{
	while (s()->tab[c->index][c->i] != 32)
		c->i++;
	while (s()->buff[c->j] != '-')
		c->j++;
	if (ft_strncmp(s()->tab[c->index], s()->buff,
		(c->i > c->j) ? c->i : c->j) == 0)
		c->occurence++;
	c->index++;
}

void		ft_last_bis(t_comp *c, int n)
{
	while (s()->tab[c->index][c->i] != 32)
		c->i++;
	while ((s()->buff + n)[c->j])
		c->j++;
	if (ft_strncmp(s()->tab[c->index], (s()->buff + n),
		(c->i > c->j) ? c->i : c->j) == 0)
		c->occurence++;
	c->index++;
}
