/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   get_tab.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tpacaly <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/04/03 10:22:15 by tpacaly           #+#    #+#             */
/*   Updated: 2018/04/03 10:22:16 by tpacaly          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../include/lemin.h"

void	ft_get_room_tab(void)
{
	int index;

	index = -1;
	while (s()->tab[++index])
	{
		while (s()->tab[index] && (ft_count(s()->tab[index]) != 2
			|| s()->tab[index][0] == '#'))
			index++;
		if (s()->tab[index] == 0)
			return ;
		s()->room = ft_malloc_tabtab(s()->room, s()->tab[index]);
	}
}

void	ft_get_pipes_bis(int *index, int *i, int *mark)
{
	while (s()->tab[*index])
	{
		*i = -1;
		*mark = 0;
		while (s()->tab[*index][++*i])
			if (s()->tab[*index][*i] == '-')
			{
				*mark = 1;
				break ;
			}
		if (*mark == 1)
			break ;
		*index = *index + 1;
	}
}

void	ft_get_pipes_tab(void)
{
	int index;
	int	i;
	int mark;

	index = -1;
	while (s()->tab[++index])
	{
		ft_get_pipes_bis(&index, &i, &mark);
		while (s()->tab[index] && s()->tab[index][0] == '#')
			index++;
		if (s()->tab[index] == 0)
			return ;
		s()->pipes = ft_malloc_tabtab(s()->pipes, s()->tab[index]);
	}
}

void	ft_get_tab(void)
{
	static char counter = 0;

	if (counter == 0)
	{
		ft_get_room_tab();
		counter++;
	}
	else if (counter == 1)
	{
		ft_get_pipes_tab();
	}
}
