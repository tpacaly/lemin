/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   chain.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tpacaly <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/04/03 10:14:21 by tpacaly           #+#    #+#             */
/*   Updated: 2018/04/03 10:14:22 by tpacaly          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../include/lemin.h"

t_list		*ft_init_lst(void)
{
	t_list	*lst;

	if (ft_strcmp(s()->room[0], s()->start_room) == 0)
		lst = ft_newroom(s()->room[0], 1, 1);
	else if (ft_strcmp(s()->room[0], s()->end_room) == 0)
		lst = ft_newroom(s()->room[0], 2, 1);
	else
		lst = ft_newroom(s()->room[0], 0, 1);
	return (lst);
}

char		*ft_cplink(char *dst, char *src, int zone)
{
	int i;
	int size;

	i = -1;
	size = 0;
	while (src[++i] != '-')
		;
	if (zone == 1)
	{
		(!(dst = (char*)malloc(sizeof(char) * i + 1))) ? exit(1) : 0;
		dst = ft_strncpy(dst, src, i);
	}
	size = i;
	while (src[++i])
		;
	if (zone == 2)
	{
		(!(dst = (char*)malloc(sizeof(char) * i - size + 2))) ? exit(1) : 0;
		dst = ft_strcpy(dst, src + size + 1);
	}
	return (dst);
}

char		**ft_fill_link(char *room, char **link, char **pipe, int n)
{
	int i;
	int j;

	i = 0;
	j = 0;
	while (i < n)
	{
		if (ft_ispipe(pipe[j], room) != -1)
		{
			if (ft_ispipe(pipe[j], room) == 0)
				link[i] = ft_cplink(link[i], pipe[j], 2);
			else
				link[i] = ft_cplink(link[i], pipe[j], 1);
			i++;
		}
		j++;
	}
	return (link);
}

int			ft_count_link(char *name, char **pipe)
{
	int n;
	int i;

	n = 0;
	i = 0;
	while (pipe[i])
	{
		if (ft_ispipe(pipe[i], name) != -1)
		{
			n++;
		}
		i++;
	}
	return (n);
}

void		ft_set_link(t_list *dst, char **pipe)
{
	int n;

	while (dst != NULL)
	{
		n = ft_count_link(dst->room, pipe);
		if (!(dst->link = (char**)malloc(sizeof(char*) * n + 1)))
			return ;
		dst->link[n] = NULL;
		dst->link = ft_fill_link(dst->room, dst->link, pipe, n);
		dst = dst->next;
	}
}
