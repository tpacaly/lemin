/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_tab.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tpacaly <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/04/03 10:15:19 by tpacaly           #+#    #+#             */
/*   Updated: 2018/04/03 10:15:25 by tpacaly          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../include/lemin.h"
#include "../include/get_next_line.h"

char	**ft_tabcpy(char **dst, char **src)
{
	int i;
	int j;

	i = 0;
	while (src[i])
	{
		j = 0;
		while (src[i][j])
		{
			dst[i][j] = src[i][j];
			j++;
		}
		dst[i][j] = 0;
		i++;
	}
	dst[i] = 0;
	return (dst);
}

char	**ft_tab(int lenx, int leny)
{
	char	**res;
	int		x;
	int		y;

	y = 0;
	if (!(res = (char **)malloc(sizeof(char*) * leny + 1)))
		return (NULL);
	while (y < leny)
	{
		if (!(res[y] = (char*)malloc(sizeof(char) * lenx + 1)))
			return (NULL);
		x = 0;
		while (x < lenx)
		{
			res[y][x] = '.';
			x++;
		}
		res[y][x] = 0;
		y++;
	}
	res[y] = 0;
	return (res);
}

char	**ft_tab_p(int lenx, int leny)
{
	char		**res;
	int			x;
	int			y;
	static int	i = 0;

	y = 0;
	if (i == 0)
		if (!(res = (char **)malloc(sizeof(char*) * leny + 1)))
			return (NULL);
	while (y < leny)
	{
		if (i == 0)
			if (!(res[y] = (char*)malloc(sizeof(char) * lenx + 1)))
				return (NULL);
		x = -1;
		while (++x < lenx)
			res[y][x] = '8';
		res[y][x] = '8';
		y++;
	}
	res[y] = 0;
	i++;
	return (res);
}
