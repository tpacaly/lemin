/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   matrice.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tpacaly <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/04/03 10:16:51 by tpacaly           #+#    #+#             */
/*   Updated: 2018/04/03 10:16:53 by tpacaly          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../include/lemin.h"

static int	ft_find_first(char *str, int value)
{
	int i;
	int nbr;

	i = -1;
	while (s()->room[++i])
	{
		nbr = 0;
		while (s()->room[i][nbr] != ' ')
			nbr++;
		if (ft_strncmp(s()->room[i], str, (value > nbr) ? value : nbr) == 0)
			return (i);
	}
	return (i);
}

static int	ft_find_second(char *str)
{
	int i;
	int	size;
	int	nbr;

	i = -1;
	size = ft_strlen(str);
	while (s()->room[++i])
	{
		nbr = 0;
		while (s()->room[i][nbr] != ' ')
			nbr++;
		if (ft_strncmp(s()->room[i], str, (size > nbr ? size : nbr)) == 0)
			return (i);
	}
	return (i);
}

static void	ft_fill_matrice(void)
{
	int index;
	int i;
	int first;
	int	second;

	index = -1;
	while (s()->pipes[++index])
	{
		i = 0;
		while (s()->pipes[index][i] != '-')
			i++;
		first = ft_find_first(s()->pipes[index], i);
		second = ft_find_second(s()->pipes[index] + i + 1);
		s()->matrice[first][second] = '1';
		s()->matrice[second][first] = '1';
	}
}

static void	ft_malloc_matrice(int size)
{
	int index;
	int i;

	index = 0;
	if (!(s()->matrice = (char **)malloc(sizeof(char *) * size + 1)))
		ft_error("malloc failure.");
	s()->matrice[size] = 0;
	while (index < size)
	{
		if (!(s()->matrice[index] = (char *)malloc(sizeof(char) * size + 1)))
			ft_error("malloc failure.");
		s()->matrice[index][size] = 0;
		i = 0;
		while (i < size)
		{
			s()->matrice[index][i] = '.';
			i++;
		}
		index++;
	}
}

void		ft_matrice(void)
{
	int	rooms_nbr;

	rooms_nbr = -1;
	while (s()->room[++rooms_nbr])
		;
	ft_malloc_matrice(rooms_nbr);
	ft_fill_matrice();
}
