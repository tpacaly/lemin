/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   utils.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tpacaly <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/04/03 10:49:40 by tpacaly           #+#    #+#             */
/*   Updated: 2018/04/03 10:49:41 by tpacaly          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../include/lemin.h"

int		ft_strncmp(const char *s1, const char *s2, size_t n)
{
	size_t	i;

	i = 0;
	if (n == 0)
		return (0);
	while (s1[i] && s2[i] && s1[i] == s2[i] && i < (n - 1))
		i++;
	return ((unsigned char)s1[i] - (unsigned char)s2[i]);
}

char	*ft_strcpy(char *dest, char *src)
{
	int i;

	i = 0;
	while (src[i])
	{
		dest[i] = src[i];
		i++;
	}
	dest[i] = '\0';
	return (dest);
}

char	*ft_strstr(const char *haystack, const char *needle)
{
	int	i;
	int	j;

	i = 0;
	j = 0;
	if (ft_strcmp(needle, "") == 0)
		return ((char *)haystack);
	while (haystack[i])
	{
		while (haystack[i] != needle[j] && haystack[i] != '\0')
			i++;
		if (haystack[i] == '\0')
			return (NULL);
		while ((haystack[i + j] == needle[j]) && needle[j] != '\0')
			j++;
		if (needle[j] == '\0')
			return ((char*)haystack + i);
		else
		{
			j = 0;
			i++;
		}
	}
	return (NULL);
}

void	ft_error(char *str)
{
	ft_putstr_fd_free(RED"ERROR"RES, 1, 0, 0);
	if (str == NULL)
	{
		write(2, "\n", 1);
		return ;
	}
	ft_putstr_fd_free(RED" : "RES, 1, 0, 0);
	ft_putstr_fd_free(str, 1, 10, 0);
	exit(1);
}

void	ft_init(int argc, char **argv)
{
	s()->av = argv;
	s()->ac = argc;
	s()->buff = NULL;
	s()->bool_start = 0;
	s()->bool_end = 0;
	s()->bool_rooms = 0;
	s()->start_room = NULL;
	s()->end_room = NULL;
	s()->ants = 0;
	s()->bool_ants = 0;
	s()->bool_stop = 0;
	s()->tab = NULL;
	s()->room_for_start = 0;
	s()->room_for_end = 0;
	s()->nbr_pipes = 0;
	s()->room = NULL;
	s()->pipes = NULL;
	s()->matrice = NULL;
	s()->path = NULL;
	s()->dist = 1;
	s()->bool_etun = 0;
	s()->result = NULL;
	s()->bonus = NULL;
}
