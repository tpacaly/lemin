/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   print_tab.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tpacaly <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/04/03 10:17:19 by tpacaly           #+#    #+#             */
/*   Updated: 2018/04/03 10:17:19 by tpacaly          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../include/lemin.h"

void	ft_color(char color, char *str)
{
	if (color == 1)
		write(1, BLU, ft_strlen(BLU));
	else if (color == 2)
		write(1, YEL, ft_strlen(YEL));
	else if (color == 3)
		write(1, BLU, ft_strlen(BLU));
	else if (color == 4)
		write(1, CYA, ft_strlen(CYA));
	else if (color == 5)
		write(1, GRE, ft_strlen(GRE));
	else if (color == 6)
		write(1, RED, ft_strlen(RED));
	else if (color == 7)
		write(1, WHI, ft_strlen(WHI));
	ft_putstr_fd_free(str, 1, 10, 0);
	if (color != 0)
		write(1, RES, ft_strlen(RES));
}

void	ft_print_color(void)
{
	int index;

	index = -1;
	while (s()->tab[++index])
	{
		if (ft_strncmp(s()->tab[index], "##start", 8) == 0)
			ft_color(5, s()->tab[index]);
		else if (ft_strncmp(s()->tab[index], "##end", 8) == 0)
			ft_color(6, s()->tab[index]);
		else if (ft_strncmp(s()->tab[index], "##", 2) == 0)
			ft_color(7, s()->tab[index]);
		else if (ft_strncmp(s()->tab[index], "#", 1) == 0 &&
			ft_strncmp(s()->tab[index], "#", 2) != 0)
			ft_color(2, s()->tab[index]);
		else if (ft_count(s()->tab[index]) == 2)
			ft_color(3, s()->tab[index]);
		else
			ft_color(4, s()->tab[index]);
	}
	write(1, "\n", 1);
}

void	ft_usage(void)
{
	ft_putstr_fd_free(CYA"usage: ./lem-in [-quiet "RES, 1, 0, 0);
	ft_putstr_fd_free(CYA"| -color | -usage] < [map]"RES, 1, 10, 0);
	ft_putstr_fd_free(CYA"       ./lem-in [-quiet "RES, 1, 0, 0);
	ft_putstr_fd_free(CYA"| -color | -usage]"RES, 1, 10, 0);
	exit(1);
}

void	ft_print_map(void)
{
	if (s()->ac == 1)
	{
		ft_puttab(s()->tab);
		return ;
	}
	if (ft_strcmp(s()->av[1], "-color") == 0)
	{
		s()->bonus = ft_strdup("-color");
		ft_print_color();
	}
	else if (ft_strcmp(s()->av[1], "-quiet") == 0 ||
		ft_strcmp(s()->av[1], "-cquiet") == 0)
	{
		s()->bonus = (ft_strcmp(s()->av[1], "-cquiet") == 0)
		? ft_strdup("-color") : NULL;
		return ;
	}
	else if (ft_strcmp(s()->av[1], "-usage") == 0)
		ft_usage();
	else if (ft_strcmp(s()->av[1], "-matrice") == 0)
		ft_puttab(s()->matrice);
	else
		ft_error("Wrong arguments.");
}
