/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ants_move.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tpacaly <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/04/03 10:14:08 by tpacaly           #+#    #+#             */
/*   Updated: 2018/04/03 10:14:11 by tpacaly          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../include/lemin.h"

void	ft_print_bonus(void)
{
	static int col = 0;

	if (s()->bonus)
	{
		(col % 2 == 0) ? ft_putstr_fd_free(GRE, 1, 0, 0) : 0;
		(col % 2 != 0) ? ft_putstr_fd_free(YEL, 1, 0, 0) : 0;
		ft_putstr_fd_free(s()->path, 1, 10, 0);
		ft_putstr_fd_free(RES, 1, 0, 0);
		col++;
	}
	else
		ft_putstr_fd_free(s()->path, 1, 10, 0);
	if (s()->path)
		ft_strdel(&s()->path);
}

void	ft_move_bis(t_list *walk, int *name, int *bool_mark)
{
	if (*bool_mark == 0)
	{
		if (walk->next)
		{
			if (walk->next->ants == 0)
			{
				ft_print(*name, walk->next->room);
				*name = *name - 1;
				*bool_mark = 1;
				walk->ants--;
				walk->next->ants = 1;
			}
			else
			{
				ft_print(*name, walk->next->room);
				*name = *name - 1;
				walk->ants--;
				walk->next->ants++;
			}
		}
	}
	else if (*bool_mark != 0)
		*bool_mark = 0;
}

void	ft_move(t_list *walk)
{
	int name;
	int bool_mark;
	int total;

	total = s()->ants;
	name = 0;
	bool_mark = 0;
	if (!s()->bonus)
		write(1, "\n", 1);
	while (ft_scroll(s()->save,
				ft_find_start_end(s()->save, 2))->ants < s()->ants)
	{
		walk = s()->save;
		name = (total + 1) - ((walk->ants > 1) ? walk->ants : 1);
		while (walk != NULL)
		{
			if (walk->ants > 0)
			{
				ft_move_bis(walk, &name, &bool_mark);
			}
			walk = walk->next;
		}
		ft_print_bonus();
	}
}

void	ft_find_path(t_list *walk, t_list *lst)
{
	int k;

	if (s()->bool_etun == 0)
		ft_error("No path found.");
	ft_print_map();
	lst = ft_scroll(s()->begin, ft_find_start_end(s()->begin, 2));
	s()->result = ft_malloc_tabtab(NULL, lst->room);
	while (lst->start != 1)
	{
		lst = ft_best_return(lst);
		s()->result = ft_malloc_tabtab(s()->result, lst->room);
	}
	k = ft_ytab(s()->result) - 1;
	walk = ft_newroom(s()->result[k], 1, 0);
	s()->save = walk;
	while (--k > 0)
	{
		walk->next = ft_newroom(s()->result[k], 0, 0);
		walk = walk->next;
	}
	walk->next = ft_newroom(s()->result[k], 2, 0);
	walk = walk->next;
	walk = s()->save;
}
