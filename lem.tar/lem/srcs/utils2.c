/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   utils2.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tpacaly <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/04/03 10:52:28 by tpacaly           #+#    #+#             */
/*   Updated: 2018/04/03 10:52:30 by tpacaly          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../include/lemin.h"

int		ft_strcmp(const char *s1, const char *s2)
{
	unsigned int	u_i;
	unsigned char	*s_1;
	unsigned char	*s_2;

	s_1 = (unsigned char *)s1;
	s_2 = (unsigned char *)s2;
	u_i = 0;
	while (s_1[u_i] && (s_1[u_i] == s_2[u_i]))
	{
		u_i++;
	}
	return ((unsigned char)s_1[u_i] - (unsigned char)s_2[u_i]);
}

void	itoa_isnegative(int *n, int *negative)
{
	if (*n < 0)
	{
		*n *= -1;
		*negative = 1;
	}
}

char	*ft_itoa(int n)
{
	int		tmpn;
	int		len;
	int		negative;
	char	*str;

	if (n == -2147483648)
		return (ft_strdup("-2147483648"));
	tmpn = n;
	len = 2;
	negative = 0;
	itoa_isnegative(&n, &negative);
	while (tmpn /= 10)
		len++;
	len += negative;
	if ((str = (char*)malloc(sizeof(char) * len)) == NULL)
		return (NULL);
	str[--len] = '\0';
	while (len--)
	{
		str[len] = n % 10 + '0';
		n = n / 10;
	}
	if (negative)
		str[0] = '-';
	return (str);
}

char	*ft_strncpy(char *dst, char *src, int n)
{
	int i;

	i = 0;
	while (src[i] && n > 0)
	{
		dst[i] = src[i];
		i++;
		n--;
	}
	dst[i] = 0;
	return (dst);
}

void	ft_putstr_fd_free(char *str, int fd, char c, char dom)
{
	write(fd, str, ft_strlen(str));
	(dom == 1) ? free(str) : 0;
	(c == 0) ? 0 : write(fd, &c, 1);
}
