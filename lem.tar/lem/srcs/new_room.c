/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   new_room.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tpacaly <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/04/03 10:17:04 by tpacaly           #+#    #+#             */
/*   Updated: 2018/04/03 10:17:05 by tpacaly          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../include/lemin.h"

t_list		*ft_setroom(t_list *dst, char *data, int i)
{
	dst->x = ft_atoi(data + i);
	while (data[++i] != ' ')
		;
	dst->y = ft_atoi(data + i);
	return (dst);
}

t_list		*ft_newroom(char *data, char start, int xy)
{
	t_list	*ret;
	int		i;

	i = 0;
	if (!(ret = (t_list*)malloc(sizeof(t_list))))
		return (NULL);
	while (data[i] != ' ' && data[i] != 0)
		i++;
	if (!(ret->room = (char*)malloc(sizeof(char) * i + 1)))
		return (NULL);
	ret->room = ft_strncpy(ret->room, data, i);
	if (xy == 1)
		ret = ft_setroom(ret, data, i);
	ret->start = start;
	ret->marker = 0;
	ret->ants = start == 1 ? s()->ants : 0;
	ret->next = NULL;
	ret->link = NULL;
	return (ret);
}
