/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   get_next_line.h                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tpacaly <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/04/03 10:23:23 by tpacaly           #+#    #+#             */
/*   Updated: 2018/04/03 10:23:24 by tpacaly          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef GET_NEXT_LINE_H
# define GET_NEXT_LINE_H
# include <stdlib.h>
# include <unistd.h>
# include <fcntl.h>
# define BUFF_SIZE 32

typedef struct	s_file
{
	int			fd;
	char		*buf;
}				t_file;
int				get_next_line(const int fd, char **line);

char			*ft_strjoin(char const *s1, char const *s2);
void			ft_strdel(char **as);
char			*ft_strdup(const char *str);
char			*ft_strnew(size_t size);
char			*ft_strchr(char *str, int c);
size_t			ft_strlen(const char *s);
#endif
