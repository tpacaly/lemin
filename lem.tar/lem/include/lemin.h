/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   lemin.h                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tpacaly <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/04/03 10:23:29 by tpacaly           #+#    #+#             */
/*   Updated: 2018/04/03 10:23:29 by tpacaly          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef LEMIN_H
# define LEMIN_H
# include <stdlib.h>
# include <unistd.h>
# include <fcntl.h>
# include "get_next_line.h"
# define RED "\x1B[31m"
# define GRE "\x1B[32m"
# define YEL "\x1B[90m"
# define BLU "\x1B[95m"
# define MAG "\x1B[95m"
# define CYA "\x1B[96m"
# define WHI "\x1B[93m"
# define RES "\x1B[0m"

typedef struct		s_comp
{
	int				occurence;
	int				index;
	int				limit;
	int				i;
	int				j;
}					t_comp;

typedef struct		s_list
{
	char			*room;
	int				x;
	int				y;
	size_t			ants;
	char			**link;
	char			*path;
	char			start;
	int				marker;
	struct s_list	*next;
}					t_list;

typedef struct		s_var
{
	char			**av;
	int				ac;
	char			*buff;
	char			bool_start;
	char			bool_end;
	char			bool_rooms;
	char			*start_room;
	char			*end_room;
	size_t			ants;
	char			bool_ants;
	char			**tab;
	char			**room;
	char			**pipes;
	char			**matrice;
	char			bool_stop;
	char			room_for_start;
	char			room_for_end;
	int				nbr_pipes;
	int				dist;
	int				bool_etun;
	char			*path;
	char			**result;
	char			*bonus;
	char			**dtab;
	t_list			*begin;
	t_list			*save;
}					t_var;

typedef struct		s_begin
{
	t_list			*begin;
}					t_begin;

void				ft_putstr_fd_free(char *str, int fd, char c, char dom);
int					ft_check_errors(void);
void				ft_error(char *str);
size_t				ft_strlen(const char *s);
t_var				*s(void);
void				ft_check_buff(int counter);
int					ft_atoi(const char *str);
void				ft_malloc_tab(int counter);
void				ft_check_pipes(void);
void				ft_get_tab(void);
char				**ft_malloc_tabtab(char **tab, char *str);
int					ft_count(char *s);
void				ft_matrice(void);
void				*ft_memmove(void *dst, const void *src, size_t len);
t_list				*ft_newroom(char *data, char start, int xy);
char				**ft_tab(int lenx, int leny);
int					ft_ytab(char **tab);
char				**ft_tabcpy(char **dst, char **src);
void				ft_puttab(char **tab);
char				**ft_strsplit(char *str, char n);
char				*ft_strncpy(char *dst, char *src, int n);
void				ft_set_link(t_list *lst, char **tab);
int					ft_strncmp(const char *s1, const char *s2, size_t n);
void				ft_print_map(void);
char				*ft_strcpy(char *haystack, char *needle);
void				ft_algo(t_list *a);
char				**ft_malloc_tabtab(char **tab, char *str);
void				ft_print(int name, char *room);
char				*ft_itoa(int nbr);
char				*ft_strsub(char const *s, unsigned int start, size_t len);
int					ft_strcmp(const char *s1, const char *s2);
int					ft_ispipe(char *pipe, char*name);
int					ft_dash(char *str);
t_list				*ft_init_lst(void);
void				ft_first_bis(t_comp *c);
void				ft_last_bis(t_comp *c, int n);
void				ft_move(t_list *walk);
t_list				*ft_scroll(t_list *a, char *s);
char				*ft_find_start_end(t_list *a, int s);
void				ft_find_path(t_list *a, t_list *s);
t_list				*ft_best_return(t_list *a);
int					ft_replica(char **a, char *s);
int					ft_check_end(t_list *a, char **s);
int					ft_check_graph(t_list *a);
#endif
